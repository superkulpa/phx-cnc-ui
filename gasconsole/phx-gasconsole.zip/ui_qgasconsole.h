/********************************************************************************
** Form generated from reading UI file 'qgasconsole.ui'
**
** Created: Fri 16. May 09:41:26 2014
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QGASCONSOLE_H
#define UI_QGASCONSOLE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QGridLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_QGasConsole
{
public:
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_4;
    QGridLayout *gridLayout;

    void setupUi(QDialog *QGasConsole)
    {
        if (QGasConsole->objectName().isEmpty())
            QGasConsole->setObjectName(QString::fromUtf8("QGasConsole"));
        QGasConsole->resize(680, 526);
        verticalLayoutWidget = new QWidget(QGasConsole);
        verticalLayoutWidget->setObjectName(QString::fromUtf8("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(10, 10, 661, 511));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));

        verticalLayout->addLayout(horizontalLayout_4);

        gridLayout = new QGridLayout();
        gridLayout->setSpacing(6);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));

        verticalLayout->addLayout(gridLayout);


        retranslateUi(QGasConsole);

        QMetaObject::connectSlotsByName(QGasConsole);
    } // setupUi

    void retranslateUi(QDialog *QGasConsole)
    {
        QGasConsole->setWindowTitle(QApplication::translate("QGasConsole", "QGasConsole", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class QGasConsole: public Ui_QGasConsole {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QGASCONSOLE_H
